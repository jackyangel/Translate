package main

import (
	"reflect"
	"testing"
	"translate/cor"
)

func TestTranslate(t *testing.T) {
	type args struct {
		text string
		origen string
		destion string
	}

	tests :=[]struct{
		name string
		args args
		want string
	}{
		{
			name:"Translate test",
			args: args{
				"A B",
				cor.Text,
				cor.Binary,
			},
			want: "1000001 1000010",
		},
		{
			name:"Translate Error",
			args: args{
				"A B",
				cor.Morse,
				cor.Binary,
			},
			want: "no se puede traducir",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Translate(tt.args.text,tt.args.origen,tt.args.destion); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Translate() = %v, want = %v", got, tt.want)
			}
		})
	}
}