package main

import (
	"fmt"
	"translate/cor"
)



func main(){
	/*s1 := cor.NewTexttoBinary()
	s2 := cor.NewTexttoMorse()

	s1.SetNext(s2)*/

	result := Translate("A B",cor.Text,cor.Binary)
	fmt.Println("Result: ", result)
}


