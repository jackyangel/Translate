package main

func Translate(text string, fOrigen string,fDestino string) string{
	comp := GetComponents()

	result, err := comp.formats.Execute(text,fOrigen,fDestino)
	if err!=nil{
		return err.Error()
	}

	resultString := result.(string)
	return resultString
}


