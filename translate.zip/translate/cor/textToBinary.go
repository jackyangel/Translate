package cor

import (
	"errors"
	"fmt"
)

type TextToBinary struct {
	next Format
}

func NewTexttoBinary() *TextToBinary {
	return &TextToBinary{}
}
func (t *TextToBinary) Execute(object interface{},fOrigen string,fDestino string) (interface{},error){

	if fOrigen == Text && fDestino == Binary {

		fmt.Println("translate: \""+object.(string) + "\" from: "+fOrigen+" to: "+ fDestino)

		var result string
		str := object.(string)

		for _, c := range str {
			if c != 32{
				result = fmt.Sprintf("%s%b",result, c)
			}else {
				result = fmt.Sprintf("%s%s",result, " ")
			}

		}

		return result,nil
	}

	if t.next != nil{
		return t.next.Execute(object,fOrigen,fDestino)
	}

	return nil,errors.New("no se puede traducir")
}

func (t *TextToBinary)SetNext(step Format)  {
	t.next = step
}
