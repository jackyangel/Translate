package cor

const(
	Text = "text"
	Binary = "binary"
	Morse = "morse"
)

type Format interface {
	Execute(object interface{},fOrigen string,fDestino string) (interface{},error)
	SetNext(format Format)
}

