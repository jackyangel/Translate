package cor

import (
	"errors"
	"fmt"
)

type TextToMorse struct {
	next Format
}

func NewTexttoMorse() *TextToMorse {
	return &TextToMorse{}
}
func (t *TextToMorse) Execute(object interface{},fOrigen string,fDestino string) (interface{},error){

	if fOrigen == Text && fDestino == Morse{
		fmt.Println("translate: \""+object.(string) + "\" from: "+fOrigen+" to: "+ fDestino)
		result := object.(string)

		return result,nil
	}

	if t.next != nil{
		return t.next.Execute(object,fOrigen,fDestino)
	}


	return nil,errors.New("no se puede traducir")
}


func (t *TextToMorse)SetNext(format Format)  {
	t.next = format
}
