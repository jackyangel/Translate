package main

import (
	"translate/cor"
)

type character struct{
	Text string
	Binary string
	morse string
}

type Components struct {
	c []character
	formats cor.Format
}

var components *Components

func GetComponents() *Components{
	if components == nil{
		components = &Components{
			c: initCharacter(),
			formats: initFormats(),

		}
	}
	return components
}

 func initFormats() cor.Format{
	 textToBinary  := cor.NewTexttoBinary()
	 textToMorse := cor.NewTexttoMorse()

	 textToBinary.SetNext(textToMorse)

	 return textToBinary
 }

func initCharacter() []character{
	return []character{
		{
			"a",
			"01100001",
			".-",
		},
	}
}